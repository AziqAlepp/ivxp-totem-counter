package com.ivxp.totemcounter;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.player.Player;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * IVXP Totem Counter.
 *  - A player pops a totem  -> their counter +1
 *  - YOU die                -> every counter is reset
 *  - Another player dies    -> only that player's counter is reset
 */
public class IvxpTotemCounter implements ClientModInitializer {
    public static final String MOD_ID = "ivxptotemcounter";
    public static final String BRAND = "IVXP";

    public static final Map<UUID, Integer> POPS = new LinkedHashMap<>();
    public static final Map<UUID, String> NAMES = new LinkedHashMap<>();

    @Override
    public void onInitializeClient() {
        // nothing to register: everything is driven by mixins
    }

    public static void onPop(Player player) {
        UUID id = player.getUUID();
        String name = player.getName().getString();
        int n = POPS.merge(id, 1, Integer::sum);
        NAMES.put(id, name);
        chat(Component.literal(name + " popped a totem (" + n + ")"));
    }

    public static void onDeath(Player player) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && player.getUUID().equals(mc.player.getUUID())) {
            // I died -> reset all counters, for every player
            POPS.clear();
            NAMES.clear();
            chat(Component.literal("You died - all counters reset"));
        } else {
            // someone else died -> reset only them
            UUID id = player.getUUID();
            if (POPS.remove(id) != null) {
                chat(Component.literal(player.getName().getString() + " died - counter reset"));
            }
            NAMES.remove(id);
        }
    }

    public static void clearAll() {
        POPS.clear();
        NAMES.clear();
    }

    private static void chat(Component msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui == null) return;
        MutableComponent line = Component.literal("[" + BRAND + "] ").withStyle(s -> s.withColor(0xFFD700))
                .append(msg.copy().withStyle(s -> s.withColor(0xFFFFFF)));
        mc.gui.getChat().addMessage(line);
    }
}
