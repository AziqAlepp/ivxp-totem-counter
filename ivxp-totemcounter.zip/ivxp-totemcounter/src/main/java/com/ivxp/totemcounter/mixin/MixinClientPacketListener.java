package com.ivxp.totemcounter.mixin;

import com.ivxp.totemcounter.IvxpTotemCounter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public class MixinClientPacketListener {
    @Inject(method = "handleEntityEvent", at = @At("HEAD"))
    private void ivxp$onEntityEvent(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        // this handler is first entered on the network thread; only act on the game thread
        if (!mc.isSameThread() || mc.level == null) return;

        Entity entity = packet.getEntity(mc.level);
        if (!(entity instanceof Player player)) return;

        byte event = packet.getEventId();
        if (event == 35) {          // totem of undying used
            IvxpTotemCounter.onPop(player);
        } else if (event == 3) {    // death
            IvxpTotemCounter.onDeath(player);
        }
    }
}
