package com.ivxp.totemcounter.mixin;

import com.ivxp.totemcounter.IvxpTotemCounter;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mixin(Gui.class)
public class MixinGui {
    private static Level ivxp$lastLevel;

    @Inject(method = "render", at = @At("TAIL"))
    private void ivxp$renderCounter(GuiGraphics g, DeltaTracker delta, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        // new world / server -> start clean
        if (ivxp$lastLevel != mc.level) {
            ivxp$lastLevel = mc.level;
            IvxpTotemCounter.clearAll();
        }
        if (mc.options.hideGui || IvxpTotemCounter.POPS.isEmpty()) return;

        Font font = mc.font;
        List<Map.Entry<UUID, Integer>> rows = new ArrayList<>(IvxpTotemCounter.POPS.entrySet());
        rows.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        int x = 4, y = 4;
        g.drawString(font, IvxpTotemCounter.BRAND + " Totem Counter", x, y, 0xFFFFD700, true);
        y += 11;
        int shown = 0;
        for (Map.Entry<UUID, Integer> e : rows) {
            if (shown++ >= 8) break;
            String name = IvxpTotemCounter.NAMES.getOrDefault(e.getKey(), "?");
            g.drawString(font, name + ": " + e.getValue(), x, y, 0xFFFFFFFF, true);
            y += 10;
        }
    }
}
